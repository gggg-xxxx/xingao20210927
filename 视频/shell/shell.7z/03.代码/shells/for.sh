#!/bin/bash

#求100以内的和

sum=0
for((i=0;i<=100;i++))
do
 sum=$[$sum+$i]
done

echo $sum
