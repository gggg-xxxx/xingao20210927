#!/bin/bash

case $1 in

"1")
 echo "北京"
;;

"2")
 echo "上海"
;;

*)
 echo "武汉"
;;

esac

