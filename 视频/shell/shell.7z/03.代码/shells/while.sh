#!/bin/bash

i=0
sum=0
while [ $i -le 100 ]
do
 #运算
 sum=$[$sum+$i]
 #i++
 i=$[$i+1]
done

echo $sum
