#!/bin/bash

if [ $1 -eq 1 ]
 then
   echo "北京大雾霾"
elif [ $1 -eq 2 ]
 then 
   echo "北京沙尘暴"
else
  echo "晴天了！！！"
fi
