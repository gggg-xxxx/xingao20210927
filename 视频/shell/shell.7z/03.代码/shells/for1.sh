#!/bin/bash
#100求和
sum=0
for((i=0; i <= 100; i++))
do
 sum=$[$i+$sum]
done

echo $sum
