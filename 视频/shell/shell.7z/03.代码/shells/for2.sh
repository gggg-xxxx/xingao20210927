#!/bin/bash

for i in "$*"
do
 echo "我的女神：$i"
done


for j in "$@"
do
 echo "我的女神：$j"
done

