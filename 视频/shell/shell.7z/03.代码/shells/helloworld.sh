#!/bin/bash

echo "hello world!!!"

echo $A

echo $PATH
