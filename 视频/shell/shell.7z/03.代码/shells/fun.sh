#!/bin/bash

#定义函数 两个数相加

function sum()
{
  total=$[$1+$2]
 # return $total
}

read -t 5 -p "请输入第一个数字：" N1
read -t 5 -p "请输入第二个数字：" N2


#调用函数
sum $N1 $N2

#echo $?
echo $total

